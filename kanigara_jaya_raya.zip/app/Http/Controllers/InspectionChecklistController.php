<?php

namespace App\Http\Controllers;

use App\Models\InspectionChecklist;
use App\Http\Requests\StoreInspectionChecklistRequest;
use App\Http\Requests\UpdateInspectionChecklistRequest;

class InspectionChecklistController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(StoreInspectionChecklistRequest $request)
    {
        //
    }

    /**
     * Display the specified resource.
     */
    public function show(InspectionChecklist $inspectionChecklist)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(InspectionChecklist $inspectionChecklist)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(UpdateInspectionChecklistRequest $request, InspectionChecklist $inspectionChecklist)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(InspectionChecklist $inspectionChecklist)
    {
        //
    }
}
